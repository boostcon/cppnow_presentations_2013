/****************************************************************************
**
** Copyright (C) 2013 Intel Corporation.
**
** You may use this file under the terms of the BSD license as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of Digia Plc and its Subsidiary(-ies) nor the names
**     of its contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
****************************************************************************/

#include <QApplication>
#include <QDebug>
#include <QFile>
#include <QProgressDialog>
#include <QProcess>
#include <QTcpSocket>
#include <QNetworkProxy>
#include "pipereader.h"
#include "threadedpipereader.h"

#include <stdio.h>

class AsyncProcess : public QObject
{
    Q_OBJECT
public:
    AsyncProcess()
    {
        auto proc = new QProcess;
        connect(proc, (void (QProcess::*)(int))&QProcess::finished, [=]() {
            proc->readLine(); // skip first line
            proc->deleteLater();
            emit dataReceived(proc->readLine().trimmed());
        });
        proc->start("qmake", QStringList() << "-v");
    }
signals:
    void dataReceived(const QByteArray &data);
};

QByteArray syncProcess()
{
    QProcess proc;
    proc.start("qmake", QStringList() << "-v");
    proc.waitForFinished();

    proc.readLine(); // skip first line
    return proc.readLine().trimmed();
}

QByteArray gopher()
{
    QTcpSocket socket;
    socket.connectToHost("gopher.floodgap.com", 70);
    socket.write("/feeds/latest\r\n");
    socket.waitForDisconnected();
    return socket.readAll();
}

QByteArray http09Downloader()
{
    QTcpSocket socket;
    socket.connectToHost("qt-project.org", 80);
    socket.write("GET /\r\n");
    socket.waitForDisconnected();
    return socket.readAll();
}

QByteArray nestedLoop()
{
    QEventLoop loop;
    QByteArray data;
    PipeReader reader(fileno(stdin));
    QObject::connect(&reader, &PipeReader::dataReceived,
                     [&](const QByteArray &newData) { data += newData; });
    QObject::connect(&reader, &PipeReader::channelClosed, &loop, &QEventLoop::quit);

    loop.exec();
    return data;
}

int progressDialog()
{
    QProgressDialog dialog("Bytes received", "Stop reading", 0, 100); // expect 100 bytes
    PipeReader reader(fileno(stdin));
    QObject::connect(&reader, &PipeReader::channelClosed,
                     &dialog, &QProgressDialog::accept);
    QObject::connect(&reader, &PipeReader::dataReceived, [&](const QByteArray &data) {
        qDebug() << "Received" << data.length() << "bytes";
        dialog.setValue(qMin(dialog.maximum(), dialog.value() + data.length()));
    });

    dialog.exec();
    return dialog.result() == QDialog::Accepted ? 0 : 1;
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QNetworkProxyFactory::setUseSystemConfiguration(true);

    if (argc > 1 && strcmp(argv[1], "synchronous") == 0) {
        qDebug() << "Synchronous read:" << nestedLoop();
        return 0;
    }
    if (argc > 1 && strcmp(argv[1], "gui") == 0) {
        return progressDialog();
    }
    if (argc > 1 && strcmp(argv[1], "threaded1") == 0) {
        ThreadedPipeReader1 reader(fileno(stdin));
        QObject::connect(&reader, &ThreadedPipeReader1::dataReceived, [](const QByteArray &data){
            qDebug() << "Received" << data.length() << "bytes";
        });
        reader.start();
        reader.wait();
        return 0;
    }
    if (argc > 1 && strcmp(argv[1], "threaded2") == 0) {
        ThreadedPipeReader2 reader(fileno(stdin));
        QObject::connect(&reader, &ThreadedPipeReader2::dataReceived, [](const QByteArray &data){
            qDebug() << "Received" << data.length() << "bytes";
        });
        reader.start();
        reader.wait();
        return 0;
    }
    if (argc > 1 && strcmp(argv[1], "file") == 0) {
        // assume stdin is a file
        // we could check with fstat(fileno(stdin))
        QFile f;
        f.open(stdin, QIODevice::ReadOnly | QIODevice::Text);
        while (!f.atEnd()) {
            QByteArray line = f.readLine().trimmed();
            qDebug() << "Line is" << line.length() << "bytes long";
        }
        return 0;
    }
    if (argc > 1 && strcmp(argv[1], "sync-process") == 0) {
        qDebug() << "Qt:" << syncProcess();
        return 0;
    }
    if (argc > 1 && strcmp(argv[1], "async-process") == 0) {
        AsyncProcess proc;
        QObject::connect(&proc, &AsyncProcess::dataReceived, [](const QByteArray &data) {
            qDebug() << "Qt:" << data;
            qApp->quit();
        });
        return a.exec();
    }
    if (argc > 1 && strcmp(argv[1], "http/0.9") == 0) {
        qDebug() << http09Downloader();
        return 0;
    }
    if (argc > 1 && strcmp(argv[1], "gopher") == 0) {
        qDebug() << gopher();
        return 0;
    }


    PipeReader reader(fileno(stdin));
    QObject::connect(&reader, &PipeReader::channelClosed, &QCoreApplication::quit);
    QObject::connect(&reader, &PipeReader::dataReceived, [](const QByteArray &data) {
        qDebug() << "Received" << data.length() << "bytes";
    });

    QTimer timer;
    timer.setInterval(2000);
    QObject::connect(&timer, &QTimer::timeout, []() {
        qDebug() << "Timed out";
        qApp->exit(1);
    });

    timer.start();
    return a.exec();
}

#include "main.moc"
