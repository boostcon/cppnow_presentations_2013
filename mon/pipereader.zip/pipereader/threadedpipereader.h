/****************************************************************************
**
** Copyright (C) 2013 Intel Corporation.
**
** You may use this file under the terms of the BSD license as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of Digia Plc and its Subsidiary(-ies) nor the names
**     of its contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
****************************************************************************/
#ifndef THREADEDPIPEREADER_H
#define THREADEDPIPEREADER_H

#include <QThread>
#include <unistd.h>

class PipeReader;

class ThreadedPipeReader1 : public QThread
{
    Q_OBJECT
public:
    ThreadedPipeReader1(int fd, QObject *parent = 0) :
        QThread(parent), m_fd(fd)
    { }
    void run()
    {
        forever {
            QByteArray buffer(4096, Qt::Uninitialized);
            ssize_t r = ::read(m_fd, buffer.data(), buffer.size());
            if (r <= 0)
                return;
            buffer.resize(r);
            emit dataReceived(buffer);
        }
    }

signals:
    void dataReceived(const QByteArray &data);

private:
    int m_fd;
};

class ThreadedPipeReader2 : public QThread
{
    Q_OBJECT
public:
    ThreadedPipeReader2(int fd, QObject *parent = 0);
    void run();

signals:
    void dataReceived(const QByteArray &data);

private:
    PipeReader *reader;
};

#endif // THREADEDPIPEREADER_H
